
function login(){
    alert("Firebase login will be added after config.");
}
